extends Node

# === РАМКИ ===

var frames_data = {
	1: {
		"name": "Bronze Basic",
		"rarity": "COMMON",
		"description": "Простая бронзовая рамка. Отличное начало для каждого новичка!",
		"stars": 1,
		"unlock_level": 0
	}
	# Остальные рамки (2-18) будут добавлены позже через Battle Pass
}

# === АВАТАРКИ ===

var avatars_data = {
	1: {
		"name": "Гейм-Космонавт",
		"rarity": "COMMON",
		"description": "Готов к межгалактическим рейдам! Этот космонавт не выпускает геймпад даже в невесомости.",
		"stars": 1,
		"unlock_level": 0
	},
	2: {
		"name": "Любитель Побед",
		"rarity": "COMMON",
		"description": "Каждая победа дарит ему радость! Классический игрок, который ценит каждый момент в игре.",
		"stars": 1,
		"unlock_level": 0
	},
	3: {
		"name": "Стоящий Про",
		"rarity": "COMMON",
		"description": "Уверенная стойка профессионала. Всегда готов к новым вызовам и достижениям.",
		"stars": 1,
		"unlock_level": 0
	},
	4: {
		"name": "Мастер Дабстепа",
		"rarity": "COMMON",
		"description": "Победа так близка, что хочется танцевать! Стиль и скилл в одном флаконе.",
		"stars": 1,
		"unlock_level": 0
	},
	5: {
		"name": "Покоритель Вершин",
		"rarity": "COMMON",
		"description": "На вершине своей игры! Буквально. Этот астронавт знает, как подняться выше всех.",
		"stars": 1,
		"unlock_level": 0
	},
	6: {
		"name": "Расслабленный Геймер",
		"rarity": "COMMON",
		"description": "Зачем напрягаться? Лучшие победы приходят в момент максимального расслабления.",
		"stars": 1,
		"unlock_level": 0
	},
	7: {
		"name": "Уютный Страж",
		"rarity": "COMMON",
		"description": "Комфорт — залог успеха! В любимом кресле даже самые сложные боссы кажутся проще.",
		"stars": 1,
		"unlock_level": 0
	}
}

# === ФОНЫ ===

var backgrounds_data = {
	# Добавим позже
}

# === МУЗЫКА ===

var music_data = {
	# Добавим позже
}

# Получить данные предмета
func get_frame_data(frame_id: int) -> Dictionary:
	return frames_data.get(frame_id, {})

func get_avatar_data(avatar_id: int) -> Dictionary:
	return avatars_data.get(avatar_id, {})

func get_background_data(bg_id: int) -> Dictionary:
	return backgrounds_data.get(bg_id, {})

func get_music_data(music_id: int) -> Dictionary:
	return music_data.get(music_id, {})

# Получить цвет редкости
func get_rarity_color(rarity: String) -> Color:
	match rarity:
		"COMMON":
			return Color(0.7, 0.7, 0.7)
		"UNCOMMON":
			return Color(0.3, 1, 0.3)
		"RARE":
			return Color(0.2, 0.5, 1)
		"EPIC":
			return Color(0.8, 0.2, 1)
		"LEGENDARY":
			return Color(1, 0.6, 0)
		"MYTHIC":
			return Color(1, 0.84, 0)
		_:
			return Color.WHITE

# Получить звёздочки редкости
func get_rarity_stars(rarity: String) -> String:
	match rarity:
		"COMMON":
			return "⭐"
		"UNCOMMON":
			return "⭐⭐"
		"RARE":
			return "⭐⭐⭐"
		"EPIC":
			return "⭐⭐⭐⭐"
		"LEGENDARY":
			return "⭐⭐⭐⭐⭐"
		"MYTHIC":
			return "⭐⭐⭐⭐⭐⭐"
		_:
			return ""
